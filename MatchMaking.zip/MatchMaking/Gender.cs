﻿namespace MatchMaking
{
    internal enum Gender
    {
        Male,
        Female
    }
}
